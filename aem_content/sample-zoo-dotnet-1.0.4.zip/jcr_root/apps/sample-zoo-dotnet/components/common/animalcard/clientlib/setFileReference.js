var remoteImageCompAfterEdit;

if (typeof remoteImageCompAfterEdit !== 'function')
{

    // update the filePath property after edit
    remoteImageCompAfterEdit = function(comp)
    {

        var that = this,
            argv = arguments,
            done = function()
            {

                var win;

                if (typeof Granite !== 'undefined' && 
                    Granite.author && Granite.author.ContentFrame) {
                    // touch ui
                    var dom = Granite.author.ContentFrame.getDocument().get(0);
                    win = /*old ie*/dom.parentWindow || dom.defaultView;

                }
                else
                {
                    win = window;
                }

                if (win.dispatchEvent(new CustomEvent("cmscomponentchange", {
                    detail: {
                        type: 'edit',
                        thisArg: that,
                        arguments: argv
                    },
                    cancelable: true
                })))
                {
                    win.location.reload(); // reload the page if the event is not default prevented
                    // comp.refresh(); careful: calling refresh on afteredit may cause an endless loop
                }
                // else, event is default prevented

                that = argv = done = null;
                
            };
        
        if (typeof $CQ === 'function')
        {
            
            $CQ.getJSON(comp.path + '.infinity.json').done(function(json)
            {

				json = json.image;

                var setFilePath = function()
                {

                    var filePath = null,
                        // cannot simply use the fileReference as it is used by aem to know
                        // whether the file is coming from an external source.
                        // thus we create our own.
                    	property = 'filePath',
                    	data = {};

                    if (json && 
                        !json.fileReference && 
                            json.file && 
                                json.file['jcr:primaryType'] === 'nt:file')
                    {
                        filePath = comp.path + '/image/file';

                    }
                    else if (json && json.fileReference)
                    {
                        filePath = json.fileReference;
                    }

                    if (!filePath)
                    {
                        property += '@Delete';
                    }

                    data[property] = String(filePath); // important to potentially cast null to 'null'

                    $CQ.ajax({
                        url: comp.path + '/image',
                        type: 'POST',
                        data: data
                    }).always(done);
                }

                if (json && !json['sling:resourceType'])
                {
                    // fix aem bug: resourceType not added when image
                    // is dropped from classic ui content finder
					$CQ.ajax({
                        url: comp.path + '/image',
                        type: 'POST',
                        data: {'sling:resourceType': 'foundation/components/image'}
                    }).always(setFilePath);
                }
                else
                {
                    setFilePath();
                }

            });
            
        }
        
    }
    
}